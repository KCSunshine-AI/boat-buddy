import { openDB, IDBPDatabase } from 'idb';
import type { BoatProfile, LogEntry, LibraryItem, LibraryItemType, SystemTag, Attribution } from './types';

export interface BoatDB extends IDBPDatabase {
  // typed DB omitted; idb generic API will be used
}

const DB_NAME = 'boat-buddy-db';
const DB_VERSION = 1;

// Keys for object stores
const PROFILE_STORE = 'profile';
const LOG_STORE = 'logEntries';
const LIB_STORE = 'libraryItems';

// Sample seed data
const sampleLog: LogEntry = {
  id: crypto.randomUUID(),
  date: new Date().toISOString().substring(0, 10),
  engine_hours: undefined,
  system_tags: ['General'],
  title: 'Sample Log Entry',
  notes: 'This is a seeded log entry demonstrating the logbook.',
  attribution: 'User',
  photo_thumbnails: [],
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString(),
};

const sampleJob: LibraryItem = {
  id: crypto.randomUUID(),
  item_type: 'JobCard',
  title: 'Sample Job Card',
  content: 'This is a sample job card. Describe how to perform a maintenance task here.',
  system_tags: ['Cooling'],
  attribution: 'Technical',
  photo_thumbnails: [],
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString(),
};

const sampleTrouble: LibraryItem = {
  id: crypto.randomUUID(),
  item_type: 'TroubleshootingTree',
  title: 'Sample Troubleshooting Tree',
  content: 'Describe the troubleshooting steps for a common issue.',
  system_tags: ['Electrical'],
  attribution: 'Technical',
  photo_thumbnails: [],
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString(),
};

const sampleNote: LibraryItem = {
  id: crypto.randomUUID(),
  item_type: 'ReferenceNote',
  title: 'Sample Reference Note',
  content: 'A reference note about your vessel.',
  system_tags: ['General'],
  attribution: 'Field',
  photo_thumbnails: [],
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString(),
};

async function createDB() {
  return openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      // Create object stores
      if (!db.objectStoreNames.contains(PROFILE_STORE)) {
        const store = db.createObjectStore(PROFILE_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(LOG_STORE)) {
        const store = db.createObjectStore(LOG_STORE, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(LIB_STORE)) {
        const store = db.createObjectStore(LIB_STORE, { keyPath: 'id' });
      }
    },
  });
}

let _dbPromise: Promise<IDBPDatabase> | null = null;

export function getDB() {
  if (!_dbPromise) {
    _dbPromise = createDB().then(async (db) => {
      // Seed data if first time (no logs or library)
      const logCount = await db.count(LOG_STORE);
      const libCount = await db.count(LIB_STORE);
      const profileCount = await db.count(PROFILE_STORE);
      if (profileCount === 0) {
        const defaultProfile: BoatProfile = {
          id: 'profile',
          boat_name: '',
          engine_model: '',
          notes: '',
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        };
        await db.add(PROFILE_STORE, defaultProfile);
      }
      if (logCount === 0) {
        await db.add(LOG_STORE, sampleLog);
      }
      if (libCount === 0) {
        await db.add(LIB_STORE, sampleJob);
        await db.add(LIB_STORE, sampleTrouble);
        await db.add(LIB_STORE, sampleNote);
      }
      return db;
    });
  }
  return _dbPromise;
}

// Boat profile functions
export async function getProfile(): Promise<BoatProfile> {
  const db = await getDB();
  const profile = await db.get(PROFILE_STORE, 'profile');
  return profile as BoatProfile;
}

export async function saveProfile(profile: BoatProfile) {
  const db = await getDB();
  profile.updated_at = new Date().toISOString();
  await db.put(PROFILE_STORE, profile);
}

// Log entry functions
export async function getLogEntries(): Promise<LogEntry[]> {
  const db = await getDB();
  const entries = await db.getAll(LOG_STORE);
  // sort by date descending
  return entries.sort((a: any, b: any) => (a.date < b.date ? 1 : -1)) as LogEntry[];
}

export async function getLogEntry(id: string): Promise<LogEntry | undefined> {
  const db = await getDB();
  const entry = await db.get(LOG_STORE, id);
  return entry as LogEntry | undefined;
}

export async function addLogEntry(entry: LogEntry) {
  const db = await getDB();
  entry.id = entry.id || crypto.randomUUID();
  entry.created_at = new Date().toISOString();
  entry.updated_at = entry.created_at;
  await db.add(LOG_STORE, entry);
}

export async function updateLogEntry(entry: LogEntry) {
  const db = await getDB();
  entry.updated_at = new Date().toISOString();
  await db.put(LOG_STORE, entry);
}

export async function deleteLogEntry(id: string) {
  const db = await getDB();
  await db.delete(LOG_STORE, id);
}

// Library item functions
export async function getLibraryItems(): Promise<LibraryItem[]> {
  const db = await getDB();
  const items = await db.getAll(LIB_STORE);
  return items as LibraryItem[];
}

export async function getLibraryItem(id: string): Promise<LibraryItem | undefined> {
  const db = await getDB();
  const item = await db.get(LIB_STORE, id);
  return item as LibraryItem | undefined;
}

export async function addLibraryItem(item: LibraryItem) {
  const db = await getDB();
  item.id = item.id || crypto.randomUUID();
  item.created_at = new Date().toISOString();
  item.updated_at = item.created_at;
  await db.add(LIB_STORE, item);
}

export async function updateLibraryItem(item: LibraryItem) {
  const db = await getDB();
  item.updated_at = new Date().toISOString();
  await db.put(LIB_STORE, item);
}

export async function deleteLibraryItem(id: string) {
  const db = await getDB();
  await db.delete(LIB_STORE, id);
}

// Export/Import functions
export interface BoatBackup {
  profile: BoatProfile;
  logEntries: LogEntry[];
  libraryItems: LibraryItem[];
}

export async function exportBoatBackup(): Promise<BoatBackup> {
  const profile = await getProfile();
  const logs = await getLogEntries();
  const libs = await getLibraryItems();
  return {
    profile,
    logEntries: logs,
    libraryItems: libs,
  };
}

export async function importBoatBackup(data: BoatBackup) {
  const db = await getDB();
  const tx = db.transaction([PROFILE_STORE, LOG_STORE, LIB_STORE], 'readwrite');
  // clear existing
  await tx.objectStore(PROFILE_STORE).clear();
  await tx.objectStore(LOG_STORE).clear();
  await tx.objectStore(LIB_STORE).clear();
  // import
  await tx.objectStore(PROFILE_STORE).add({ ...data.profile, id: 'profile' });
  for (const log of data.logEntries) {
    await tx.objectStore(LOG_STORE).add(log);
  }
  for (const item of data.libraryItems) {
    await tx.objectStore(LIB_STORE).add(item);
  }
  await tx.done;
}

export interface KnowledgePack {
  libraryItems: LibraryItem[];
}

export async function exportKnowledgePack(): Promise<KnowledgePack> {
  const libs = await getLibraryItems();
  return { libraryItems: libs };
}

export async function importKnowledgePack(pack: KnowledgePack) {
  const db = await getDB();
  const store = db.transaction(LIB_STORE, 'readwrite').objectStore(LIB_STORE);
  let importedCount = 0;
  for (const item of pack.libraryItems) {
    // ensure required fields
    const tags = item.system_tags && item.system_tags.length > 0 ? item.system_tags : ['Unsorted'];
    const attribution: Attribution = (item.attribution as Attribution) || 'Field (needs review)';
    const newItem: LibraryItem = {
      ...item,
      id: crypto.randomUUID(),
      system_tags: tags as SystemTag[],
      attribution,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    await store.add(newItem);
    importedCount++;
  }
  return importedCount;
}