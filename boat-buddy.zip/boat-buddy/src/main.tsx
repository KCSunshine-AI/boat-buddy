import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

// Register service worker for PWA
// vite-plugin-pwa provides virtual module to register the SW
import { registerSW } from 'virtual:pwa-register';

const updateSW = registerSW({ immediate: true });

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);