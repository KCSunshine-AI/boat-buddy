import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getLogEntries } from '../db';
import type { LogEntry, SystemTag } from '../types';

const TAGS: (SystemTag | 'All')[] = ['All', 'Cooling', 'Fuel', 'Exhaust', 'Electrical', 'General', 'Unsorted'];

const LogbookList: React.FC = () => {
  const [entries, setEntries] = useState<LogEntry[]>([]);
  const [filter, setFilter] = useState<SystemTag | 'All'>('All');

  useEffect(() => {
    (async () => {
      const logs = await getLogEntries();
      setEntries(logs);
    })();
  }, []);

  const filtered = entries.filter((e) => (filter === 'All' ? true : e.system_tags.includes(filter)));

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Logbook</h2>
        <Link
          to="/logbook/new"
          className="bg-accent text-primary px-4 py-2 rounded hover:bg-accent-dark"
        >
          + New
        </Link>
      </div>
      <div className="mb-4">
        <label className="mr-2">Filter:</label>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as any)}
          className="border rounded px-2 py-1"
        >
          {TAGS.map((tag) => (
            <option key={tag} value={tag}>
              {tag}
            </option>
          ))}
        </select>
      </div>
      {filtered.length === 0 ? (
        <p>No log entries found.</p>
      ) : (
        <ul className="space-y-2">
          {filtered.map((entry) => (
            <li
              key={entry.id}
              className="border rounded p-3 bg-white dark:bg-gray-800 flex justify-between items-center hover:shadow"
            >
              <Link to={`/logbook/${entry.id}`} className="flex-1">
                <div className="font-medium">{entry.title}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  {entry.date}
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                  {entry.system_tags.join(', ')}
                </div>
              </Link>
              {entry.photo_thumbnails.length > 0 && (
                <div className="ml-2 text-lg" title={`${entry.photo_thumbnails.length} photo(s)`}>
                  📷
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default LogbookList;