import React from 'react';
import { Link } from 'react-router-dom';

/**
 * Minimal dashboard with large action buttons for quick access. In V0 no summary stats.
 */
const Dashboard: React.FC = () => {
  const actions = [
    { to: '/logbook/new', label: 'New Log Entry', emoji: '📝' },
    { to: '/chat', label: 'Add Chat', emoji: '💬' },
    { to: '/logbook', label: 'Logbook', emoji: '📖' },
    { to: '/settings', label: 'Export', emoji: '⬇️' },
  ];
  return (
    <div className="max-w-md mx-auto">
      <h2 className="text-2xl font-semibold mb-4">Dashboard</h2>
      <div className="grid grid-cols-2 gap-4">
        {actions.map((action) => (
          <Link
            key={action.to}
            to={action.to}
            className="flex flex-col items-center justify-center p-6 bg-accent text-primary rounded-lg shadow hover:shadow-md focus:outline-none focus:ring-2 focus:ring-accent-dark transition-transform"
          >
            <span className="text-4xl mb-2" aria-hidden="true">{action.emoji}</span>
            <span className="text-center font-medium">{action.label}</span>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;