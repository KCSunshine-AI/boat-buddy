import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  addLogEntry,
  getLogEntry,
  updateLogEntry,
} from '../db';
import type { LogEntry, SystemTag, Attribution } from '../types';
import { resizeAndCompressImage } from '../utils/image';

const TAG_OPTIONS: SystemTag[] = ['Cooling', 'Fuel', 'Exhaust', 'Electrical', 'General'];
const ATTR_OPTIONS: Attribution[] = ['User', 'Technical', 'Field'];

const emptyEntry: LogEntry = {
  id: '',
  date: new Date().toISOString().substring(0, 10),
  engine_hours: undefined,
  system_tags: [],
  title: '',
  notes: '',
  attribution: 'User',
  photo_thumbnails: [],
  created_at: '',
  updated_at: '',
};

const LogEntryForm: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [entry, setEntry] = useState<LogEntry>(emptyEntry);
  const [loading, setLoading] = useState<boolean>(false);
  const isEdit = Boolean(id);

  useEffect(() => {
    if (isEdit && id) {
      (async () => {
        const data = await getLogEntry(id);
        if (data) setEntry({ ...data });
      })();
    }
  }, [id, isEdit]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setEntry((prev) => ({ ...prev, [name]: value }));
  };

  const handleTagToggle = (tag: SystemTag) => {
    setEntry((prev) => {
      const tags = prev.system_tags.includes(tag)
        ? prev.system_tags.filter((t) => t !== tag)
        : [...prev.system_tags, tag];
      return { ...prev, system_tags: tags };
    });
  };

  const handleAttributionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setEntry((prev) => ({ ...prev, attribution: e.target.value as Attribution }));
  };

  const handleImagesChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newImages: string[] = [];
    for (let i = 0; i < files.length && entry.photo_thumbnails.length + newImages.length < 3; i++) {
      const file = files[i];
      const dataUrl = await resizeAndCompressImage(file, 800, 0.7);
      newImages.push(dataUrl);
    }
    setEntry((prev) => ({ ...prev, photo_thumbnails: [...prev.photo_thumbnails, ...newImages] }));
    // reset input to allow same file selection again
    e.target.value = '';
  };

  const removeImage = (index: number) => {
    setEntry((prev) => {
      const newArr = [...prev.photo_thumbnails];
      newArr.splice(index, 1);
      return { ...prev, photo_thumbnails: newArr };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isEdit) {
        await updateLogEntry(entry);
      } else {
        await addLogEntry({ ...entry, id: crypto.randomUUID() });
      }
      navigate('/logbook');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-4">{isEdit ? 'Edit Log Entry' : 'New Log Entry'}</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">Date</label>
          <input
            type="date"
            name="date"
            value={entry.date}
            onChange={handleInputChange}
            className="border rounded px-2 py-1 w-full"
            required
          />
        </div>
        <div>
          <label className="block mb-1">Engine Hours (optional)</label>
          <input
            type="number"
            name="engine_hours"
            value={entry.engine_hours ?? ''}
            onChange={(e) => setEntry((prev) => ({ ...prev, engine_hours: e.target.value ? Number(e.target.value) : undefined }))}
            className="border rounded px-2 py-1 w-full"
          />
        </div>
        <div>
          <label className="block mb-1">System Tags</label>
          <div className="flex flex-wrap gap-2">
            {TAG_OPTIONS.map((tag) => (
              <button
                type="button"
                key={tag}
                onClick={() => handleTagToggle(tag)}
                className={`px-3 py-1 rounded-full text-sm border ${entry.system_tags.includes(tag) ? 'bg-accent text-primary border-accent' : 'bg-gray-200 dark:bg-gray-700 border-gray-300'}`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="block mb-1">Title</label>
          <input
            type="text"
            name="title"
            value={entry.title}
            onChange={handleInputChange}
            className="border rounded px-2 py-1 w-full"
            required
          />
        </div>
        <div>
          <label className="block mb-1">Notes</label>
          <textarea
            name="notes"
            value={entry.notes}
            onChange={handleInputChange}
            className="border rounded px-2 py-1 w-full h-32"
          />
        </div>
        <div>
          <label className="block mb-1">Attribution</label>
          <select
            name="attribution"
            value={entry.attribution}
            onChange={handleAttributionChange}
            className="border rounded px-2 py-1 w-full"
          >
            {ATTR_OPTIONS.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block mb-1">Photos (max 3)</label>
          <input
            type="file"
            accept="image/*"
            multiple
            onChange={handleImagesChange}
            className="block"
            capture="environment"
          />
          {entry.photo_thumbnails.length > 0 && (
            <div className="flex gap-2 mt-2">
              {entry.photo_thumbnails.map((img, idx) => (
                <div key={idx} className="relative">
                  <img src={img} alt={`thumbnail ${idx + 1}`} className="w-20 h-20 object-cover rounded" />
                  <button
                    type="button"
                    onClick={() => removeImage(idx)}
                    className="absolute top-0 right-0 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs"
                    title="Remove"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
        <div>
          <button
            type="submit"
            disabled={loading}
            className="bg-primary text-white px-4 py-2 rounded hover:bg-primary-light disabled:opacity-50"
          >
            {isEdit ? 'Update' : 'Save'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default LogEntryForm;