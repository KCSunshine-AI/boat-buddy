import React, { useState } from 'react';
import {
  exportBoatBackup,
  importBoatBackup,
  exportKnowledgePack,
  importKnowledgePack,
} from '../db';

const SettingsPage: React.FC = () => {
  const [message, setMessage] = useState('');

  const downloadJSON = (data: any, filename: string) => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportBackup = async () => {
    const backup = await exportBoatBackup();
    downloadJSON(backup, 'boat-backup.json');
    setMessage('Boat backup exported.');
  };

  const handleImportBackup = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    try {
      const data = JSON.parse(text);
      await importBoatBackup(data);
      setMessage('Boat backup imported successfully.');
    } catch (err) {
      console.error(err);
      setMessage('Invalid backup file.');
    }
    e.target.value = '';
  };

  const handleExportKP = async () => {
    const pack = await exportKnowledgePack();
    downloadJSON(pack, 'knowledge-pack.json');
    setMessage('Knowledge pack exported.');
  };

  const handleImportKP = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    try {
      const data = JSON.parse(text);
      const count = await importKnowledgePack(data);
      setMessage(`Imported ${count} library item(s).`);
    } catch (err) {
      console.error(err);
      setMessage('Invalid knowledge pack file.');
    }
    e.target.value = '';
  };

  return (
    <div className="max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-4">Settings</h2>
      <div className="space-y-4">
        <div className="border p-4 rounded">
          <h3 className="font-medium mb-2">Boat Backup</h3>
          <button
            onClick={handleExportBackup}
            className="bg-primary text-white px-4 py-2 rounded hover:bg-primary-light mr-2"
          >
            Export Backup
          </button>
          <label className="inline-block bg-accent text-primary px-4 py-2 rounded cursor-pointer hover:bg-accent-dark">
            Import Backup
            <input type="file" accept="application/json" onChange={handleImportBackup} className="hidden" />
          </label>
        </div>
        <div className="border p-4 rounded">
          <h3 className="font-medium mb-2">Knowledge Pack</h3>
          <button
            onClick={handleExportKP}
            className="bg-primary text-white px-4 py-2 rounded hover:bg-primary-light mr-2"
          >
            Export Pack
          </button>
          <label className="inline-block bg-accent text-primary px-4 py-2 rounded cursor-pointer hover:bg-accent-dark">
            Import Pack
            <input type="file" accept="application/json" onChange={handleImportKP} className="hidden" />
          </label>
        </div>
        {message && <p className="mt-2 text-sm text-green-600 dark:text-green-400">{message}</p>}
      </div>
    </div>
  );
};

export default SettingsPage;