import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getLogEntries, getLibraryItems } from '../db';
import type { LogEntry, LibraryItem } from '../types';

interface SearchResult {
  id: string;
  type: 'Log' | 'Library';
  subType?: string;
  title: string;
  snippet: string;
}

const SearchPage: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [libs, setLibs] = useState<LibraryItem[]>([]);

  useEffect(() => {
    (async () => {
      const lgs = await getLogEntries();
      const lbs = await getLibraryItems();
      setLogs(lgs);
      setLibs(lbs);
    })();
  }, []);

  useEffect(() => {
    const q = query.toLowerCase().trim();
    if (!q) {
      setResults([]);
      return;
    }
    const res: SearchResult[] = [];
    for (const log of logs) {
      const hay = `${log.title} ${log.notes} ${log.system_tags.join(' ')}`.toLowerCase();
      if (hay.includes(q)) {
        res.push({
          id: log.id,
          type: 'Log',
          title: log.title,
          snippet: log.notes.substring(0, 60) + (log.notes.length > 60 ? '...' : ''),
        });
      }
    }
    for (const item of libs) {
      const hay = `${item.title} ${item.content} ${item.system_tags.join(' ')}`.toLowerCase();
      if (hay.includes(q)) {
        res.push({
          id: item.id,
          type: 'Library',
          subType: item.item_type,
          title: item.title,
          snippet: item.content.substring(0, 60) + (item.content.length > 60 ? '...' : ''),
        });
      }
    }
    setResults(res);
  }, [query, logs, libs]);

  return (
    <div className="max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-4">Search</h2>
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search titles, notes, tags..."
        className="border rounded px-2 py-1 w-full mb-4"
      />
      {results.length === 0 && query && <p>No results found.</p>}
      <ul className="space-y-2">
        {results.map((r, idx) => (
          <li key={idx} className="border rounded p-3 bg-white dark:bg-gray-800 hover:shadow">
            {r.type === 'Log' ? (
              <Link to={`/logbook/${r.id}`}> 
                <div className="font-medium">{r.title}</div>
                <div className="text-xs text-gray-500 dark:text-gray-500">Log Entry</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">{r.snippet}</div>
              </Link>
            ) : (
              <Link to={`/library/${r.id}`}> 
                <div className="font-medium">{r.title}</div>
                <div className="text-xs text-gray-500 dark:text-gray-500">{r.subType}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">{r.snippet}</div>
              </Link>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SearchPage;