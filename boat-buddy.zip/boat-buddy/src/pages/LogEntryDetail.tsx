import React, { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { getLogEntry, deleteLogEntry } from '../db';
import type { LogEntry } from '../types';

const LogEntryDetail: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [entry, setEntry] = useState<LogEntry | null>(null);

  useEffect(() => {
    if (id) {
      (async () => {
        const data = await getLogEntry(id);
        if (data) setEntry(data);
      })();
    }
  }, [id]);

  const handleDelete = async () => {
    if (!id) return;
    if (confirm('Delete this log entry?')) {
      await deleteLogEntry(id);
      navigate('/logbook');
    }
  };

  if (!entry) {
    return <p>Loading...</p>;
  }

  return (
    <div className="max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-4">{entry.title}</h2>
      <div className="mb-2 text-sm text-gray-600 dark:text-gray-400">Date: {entry.date}</div>
      {entry.engine_hours !== undefined && (
        <div className="mb-2 text-sm text-gray-600 dark:text-gray-400">
          Engine Hours: {entry.engine_hours}
        </div>
      )}
      <div className="mb-2 text-sm">
        Tags: {entry.system_tags.join(', ')}
      </div>
      <div className="mb-2 text-sm">
        Attribution: {entry.attribution}
      </div>
      <p className="mb-4 whitespace-pre-line">{entry.notes}</p>
      {entry.photo_thumbnails.length > 0 && (
        <div className="mb-4">
          <h3 className="font-medium mb-2">Photos</h3>
          <div className="grid grid-cols-3 gap-2">
            {entry.photo_thumbnails.map((img, idx) => (
              <img
                key={idx}
                src={img}
                alt={`thumbnail ${idx + 1}`}
                className="w-full h-32 object-cover rounded cursor-pointer"
                onClick={() => window.open(img, '_blank')}
              />
            ))}
          </div>
        </div>
      )}
      <div className="flex gap-2">
        <Link
          to={`/logbook/edit/${entry.id}`}
          className="bg-accent text-primary px-4 py-2 rounded hover:bg-accent-dark"
        >
          Edit
        </Link>
        <button
          onClick={handleDelete}
          className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
        >
          Delete
        </button>
        <Link
          to={`/print/log/${entry.id}`}
          className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
          target="_blank"
        >
          Print
        </Link>
      </div>
    </div>
  );
};

export default LogEntryDetail;