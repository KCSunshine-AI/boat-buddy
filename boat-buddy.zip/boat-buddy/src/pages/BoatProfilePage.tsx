import React, { useEffect, useState } from 'react';
import { getProfile, saveProfile } from '../db';
import type { BoatProfile } from '../types';

const BoatProfilePage: React.FC = () => {
  const [profile, setProfile] = useState<BoatProfile | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    (async () => {
      const prof = await getProfile();
      setProfile(prof);
    })();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProfile((prev) => (prev ? { ...prev, [name]: value } : prev));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    setLoading(true);
    try {
      await saveProfile(profile);
      alert('Profile saved');
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (!profile) return <p>Loading...</p>;

  return (
    <div className="max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-4">Boat Profile</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">Boat Name</label>
          <input
            type="text"
            name="boat_name"
            value={profile.boat_name}
            onChange={handleChange}
            className="border rounded px-2 py-1 w-full"
          />
        </div>
        <div>
          <label className="block mb-1">Engine Model</label>
          <input
            type="text"
            name="engine_model"
            value={profile.engine_model}
            onChange={handleChange}
            className="border rounded px-2 py-1 w-full"
          />
        </div>
        <div>
          <label className="block mb-1">Notes</label>
          <textarea
            name="notes"
            value={profile.notes}
            onChange={handleChange}
            className="border rounded px-2 py-1 w-full h-32"
          />
        </div>
        <div>
          <button
            type="submit"
            disabled={loading}
            className="bg-primary text-white px-4 py-2 rounded hover:bg-primary-light disabled:opacity-50"
          >
            Save Profile
          </button>
        </div>
      </form>
    </div>
  );
};

export default BoatProfilePage;