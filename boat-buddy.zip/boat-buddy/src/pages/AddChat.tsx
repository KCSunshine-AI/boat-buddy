import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { addLogEntry, addLibraryItem } from '../db';
import type { LibraryItemType, SystemTag, Attribution } from '../types';

const TAG_OPTIONS: SystemTag[] = ['Cooling', 'Fuel', 'Exhaust', 'Electrical', 'General'];
const ATTR_OPTIONS: Attribution[] = ['User', 'Technical', 'Field'];

const AddChat: React.FC = () => {
  const navigate = useNavigate();
  const [text, setText] = useState('');
  const [destination, setDestination] = useState<'LogEntry' | LibraryItemType>('LogEntry');
  const [tags, setTags] = useState<SystemTag[]>([]);
  const [attribution, setAttribution] = useState<Attribution>('User');
  const [loading, setLoading] = useState(false);

  const toggleTag = (tag: SystemTag) => {
    setTags((prev) => (
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    ));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    setLoading(true);
    try {
      if (destination === 'LogEntry') {
        await addLogEntry({
          id: crypto.randomUUID(),
          date: new Date().toISOString().substring(0, 10),
          engine_hours: undefined,
          system_tags: tags.length > 0 ? tags : ['General'],
          title: text.trim().substring(0, 30) || 'Chat Entry',
          notes: text,
          attribution,
          photo_thumbnails: [],
          created_at: '',
          updated_at: '',
        });
        navigate('/logbook');
      } else {
        const itemType = destination as LibraryItemType;
        const title = text.trim().substring(0, 40) || 'Chat Note';
        await addLibraryItem({
          id: crypto.randomUUID(),
          item_type: itemType,
          title,
          content: text,
          system_tags: tags.length > 0 ? tags : ['General'],
          attribution,
          photo_thumbnails: [],
          created_at: '',
          updated_at: '',
        });
        navigate('/library');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-4">Add Chat</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block mb-1">Chat Text</label>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="border rounded px-2 py-1 w-full h-40"
            placeholder="Paste chat text here..."
            required
          />
        </div>
        <div>
          <label className="block mb-1">Destination</label>
          <select
            value={destination}
            onChange={(e) => setDestination(e.target.value as any)}
            className="border rounded px-2 py-1 w-full"
          >
            <option value="LogEntry">Log Entry</option>
            <option value="JobCard">JobCard</option>
            <option value="TroubleshootingTree">TroubleshootingTree</option>
            <option value="ReferenceNote">ReferenceNote</option>
          </select>
        </div>
        <div>
          <label className="block mb-1">System Tags</label>
          <div className="flex flex-wrap gap-2">
            {TAG_OPTIONS.map((tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => toggleTag(tag)}
                className={`px-3 py-1 rounded-full text-sm border ${tags.includes(tag) ? 'bg-accent text-primary border-accent' : 'bg-gray-200 dark:bg-gray-700 border-gray-300'}`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="block mb-1">Attribution</label>
          <select
            value={attribution}
            onChange={(e) => setAttribution(e.target.value as Attribution)}
            className="border rounded px-2 py-1 w-full"
          >
            {ATTR_OPTIONS.map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
        </div>
        <div>
          <button
            type="submit"
            disabled={loading}
            className="bg-primary text-white px-4 py-2 rounded hover:bg-primary-light disabled:opacity-50"
          >
            Save
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddChat;