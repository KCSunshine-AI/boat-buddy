import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getLibraryItems } from '../db';
import type { LibraryItem, LibraryItemType } from '../types';

const TYPES: (LibraryItemType | 'All')[] = ['All', 'JobCard', 'TroubleshootingTree', 'ReferenceNote'];

const LibraryList: React.FC = () => {
  const [items, setItems] = useState<LibraryItem[]>([]);
  const [filter, setFilter] = useState<LibraryItemType | 'All'>('All');

  useEffect(() => {
    (async () => {
      const data = await getLibraryItems();
      setItems(data);
    })();
  }, []);

  const filtered = items.filter((it) => (filter === 'All' ? true : it.item_type === filter));

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Library</h2>
        <Link
          to="/library/new"
          className="hidden md:block bg-accent text-primary px-4 py-2 rounded hover:bg-accent-dark"
        >
          + New
        </Link>
      </div>
      <div className="mb-4">
        <label className="mr-2">Filter:</label>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as any)}
          className="border rounded px-2 py-1"
        >
          {TYPES.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>
      {filtered.length === 0 ? (
        <p>No library items found.</p>
      ) : (
        <ul className="space-y-2">
          {filtered.map((item) => (
            <li
              key={item.id}
              className="border rounded p-3 bg-white dark:bg-gray-800 hover:shadow"
            >
              <Link to={`/library/${item.id}`} className="block">
                <div className="font-medium">{item.title}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  {item.item_type}
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                  {item.system_tags.join(', ')}
                </div>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default LibraryList;