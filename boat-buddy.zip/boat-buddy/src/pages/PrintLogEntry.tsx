import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getLogEntry } from '../db';
import type { LogEntry } from '../types';

const PrintLogEntry: React.FC = () => {
  const { id } = useParams();
  const [entry, setEntry] = useState<LogEntry | null>(null);
  useEffect(() => {
    if (id) {
      (async () => {
        const data = await getLogEntry(id);
        if (data) setEntry(data);
      })();
    }
  }, [id]);
  if (!entry) return <p>Loading...</p>;
  return (
    <div className="max-w-2xl mx-auto p-4 print:p-0">
      <h1 className="text-2xl font-bold mb-4">{entry.title}</h1>
      <div className="text-sm mb-2">Date: {entry.date}</div>
      {entry.engine_hours !== undefined && <div className="text-sm mb-2">Engine Hours: {entry.engine_hours}</div>}
      <div className="text-sm mb-2">Tags: {entry.system_tags.join(', ')}</div>
      <div className="text-sm mb-2">Attribution: {entry.attribution}</div>
      <p className="whitespace-pre-line mb-4">{entry.notes}</p>
      {entry.photo_thumbnails.length > 0 && (
        <div className="mb-4">
          <h3 className="font-medium mb-2">Photos</h3>
          {entry.photo_thumbnails.map((img, idx) => (
            <img key={idx} src={img} alt={`photo ${idx + 1}`} className="mb-2 max-w-full" />
          ))}
        </div>
      )}
    </div>
  );
};

export default PrintLogEntry;