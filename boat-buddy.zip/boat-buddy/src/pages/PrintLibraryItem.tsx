import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getLibraryItem } from '../db';
import type { LibraryItem } from '../types';

const PrintLibraryItem: React.FC = () => {
  const { id } = useParams();
  const [item, setItem] = useState<LibraryItem | null>(null);
  useEffect(() => {
    if (id) {
      (async () => {
        const data = await getLibraryItem(id);
        if (data) setItem(data);
      })();
    }
  }, [id]);
  if (!item) return <p>Loading...</p>;
  return (
    <div className="max-w-2xl mx-auto p-4 print:p-0">
      <h1 className="text-2xl font-bold mb-4">{item.title}</h1>
      <div className="text-sm mb-2">Type: {item.item_type}</div>
      <div className="text-sm mb-2">Tags: {item.system_tags.join(', ')}</div>
      <div className="text-sm mb-2">Attribution: {item.attribution}</div>
      <p className="whitespace-pre-line mb-4">{item.content}</p>
      {item.photo_thumbnails.length > 0 && (
        <div className="mb-4">
          <h3 className="font-medium mb-2">Photos</h3>
          {item.photo_thumbnails.map((img, idx) => (
            <img key={idx} src={img} alt={`photo ${idx + 1}`} className="mb-2 max-w-full" />
          ))}
        </div>
      )}
    </div>
  );
};

export default PrintLibraryItem;