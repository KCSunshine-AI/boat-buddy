import React, { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { getLibraryItem, deleteLibraryItem } from '../db';
import type { LibraryItem } from '../types';

const LibraryDetail: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [item, setItem] = useState<LibraryItem | null>(null);

  useEffect(() => {
    if (id) {
      (async () => {
        const data = await getLibraryItem(id);
        if (data) setItem(data);
      })();
    }
  }, [id]);

  const handleDelete = async () => {
    if (!id) return;
    if (confirm('Delete this item?')) {
      await deleteLibraryItem(id);
      navigate('/library');
    }
  };

  if (!item) return <p>Loading...</p>;

  return (
    <div className="max-w-xl mx-auto">
      <h2 className="text-xl font-semibold mb-4">{item.title}</h2>
      <div className="mb-2 text-sm text-gray-600 dark:text-gray-400">Type: {item.item_type}</div>
      <div className="mb-2 text-sm">Tags: {item.system_tags.join(', ')}</div>
      <div className="mb-2 text-sm">Attribution: {item.attribution}</div>
      <div className="mb-4 whitespace-pre-line">{item.content}</div>
      {item.photo_thumbnails.length > 0 && (
        <div className="mb-4">
          <h3 className="font-medium mb-2">Photos</h3>
          <div className="grid grid-cols-3 gap-2">
            {item.photo_thumbnails.map((img, idx) => (
              <img
                key={idx}
                src={img}
                alt={`thumbnail ${idx + 1}`}
                className="w-full h-32 object-cover rounded cursor-pointer"
                onClick={() => window.open(img, '_blank')}
              />
            ))}
          </div>
        </div>
      )}
      <div className="flex gap-2">
        <Link
          to={`/library/edit/${item.id}`}
          className="bg-accent text-primary px-4 py-2 rounded hover:bg-accent-dark"
        >
          Edit
        </Link>
        <button
          onClick={handleDelete}
          className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
        >
          Delete
        </button>
        <Link
          to={`/print/library/${item.id}`}
          className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
          target="_blank"
        >
          Print
        </Link>
      </div>
    </div>
  );
};

export default LibraryDetail;