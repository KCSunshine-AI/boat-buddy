export type SystemTag = 'Cooling' | 'Fuel' | 'Exhaust' | 'Electrical' | 'General' | 'Unsorted';

export type Attribution = 'User' | 'Technical' | 'Field' | 'Field (needs review)';

// Represents the single boat profile. Only one record should exist.
export interface BoatProfile {
  id: string; // static id for object store, e.g. 'profile'
  boat_name: string;
  engine_model: string;
  notes: string;
  created_at: string;
  updated_at: string;
}

// Represents a logbook entry recorded by the user.
export interface LogEntry {
  id: string;
  date: string;
  engine_hours?: number;
  system_tags: SystemTag[];
  title: string;
  notes: string;
  attribution: Attribution;
  photo_thumbnails: string[]; // base64 encoded JPEG thumbnails
  created_at: string;
  updated_at: string;
}

export type LibraryItemType = 'JobCard' | 'TroubleshootingTree' | 'ReferenceNote';

// Represents a library item (job card, troubleshooting tree, or reference note)
export interface LibraryItem {
  id: string;
  item_type: LibraryItemType;
  title: string;
  content: string;
  system_tags: SystemTag[];
  attribution: Attribution;
  photo_thumbnails: string[];
  created_at: string;
  updated_at: string;
}