import React from 'react';
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import LogbookList from './pages/LogbookList';
import LogEntryForm from './pages/LogEntryForm';
import LogEntryDetail from './pages/LogEntryDetail';
import LibraryList from './pages/LibraryList';
import LibraryForm from './pages/LibraryForm';
import LibraryDetail from './pages/LibraryDetail';
import AddChat from './pages/AddChat';
import BoatProfilePage from './pages/BoatProfilePage';
import SettingsPage from './pages/SettingsPage';
import SearchPage from './pages/SearchPage';
import PrintLogEntry from './pages/PrintLogEntry';
import PrintLibraryItem from './pages/PrintLibraryItem';

function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen flex flex-col md:flex-row">
        {/* Sidebar for desktop */}
        <nav className="hidden md:flex md:flex-col md:w-60 bg-primary dark:bg-primary-dark text-white p-4 space-y-2">
          <h1 className="text-xl font-semibold mb-4">Boat Buddy</h1>
          <NavLink to="/" end className={({ isActive }) => `block px-3 py-2 rounded ${isActive ? 'bg-accent text-primary' : 'hover:bg-primary-light'}`}>Dashboard</NavLink>
          <NavLink to="/logbook" className={({ isActive }) => `block px-3 py-2 rounded ${isActive ? 'bg-accent text-primary' : 'hover:bg-primary-light'}`}>Logbook</NavLink>
          <NavLink to="/library" className={({ isActive }) => `block px-3 py-2 rounded ${isActive ? 'bg-accent text-primary' : 'hover:bg-primary-light'}`}>Library</NavLink>
          <NavLink to="/chat" className={({ isActive }) => `block px-3 py-2 rounded ${isActive ? 'bg-accent text-primary' : 'hover:bg-primary-light'}`}>Add Chat</NavLink>
          <NavLink to="/profile" className={({ isActive }) => `block px-3 py-2 rounded ${isActive ? 'bg-accent text-primary' : 'hover:bg-primary-light'}`}>Boat Profile</NavLink>
          <NavLink to="/settings" className={({ isActive }) => `block px-3 py-2 rounded ${isActive ? 'bg-accent text-primary' : 'hover:bg-primary-light'}`}>Settings</NavLink>
          <NavLink to="/search" className={({ isActive }) => `block px-3 py-2 rounded ${isActive ? 'bg-accent text-primary' : 'hover:bg-primary-light'}`}>Search</NavLink>
        </nav>
        {/* Main content area */}
        <div className="flex-1 p-4 pb-20 md:pb-4 overflow-y-auto">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/logbook" element={<LogbookList />} />
            <Route path="/logbook/new" element={<LogEntryForm />} />
            <Route path="/logbook/edit/:id" element={<LogEntryForm />} />
            <Route path="/logbook/:id" element={<LogEntryDetail />} />
            <Route path="/library" element={<LibraryList />} />
            <Route path="/library/new" element={<LibraryForm />} />
            <Route path="/library/edit/:id" element={<LibraryForm />} />
            <Route path="/library/:id" element={<LibraryDetail />} />
            <Route path="/chat" element={<AddChat />} />
            <Route path="/profile" element={<BoatProfilePage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/search" element={<SearchPage />} />
            {/* Print views (no navigation) */}
            <Route path="/print/log/:id" element={<PrintLogEntry />} />
            <Route path="/print/library/:id" element={<PrintLibraryItem />} />
          </Routes>
        </div>
        {/* Bottom nav for mobile */}
        <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-primary dark:bg-primary-dark text-white flex justify-between items-center px-2 py-2 space-x-1">
          <NavLink to="/" end className={({ isActive }) => `flex-1 text-center py-2 rounded ${isActive ? 'bg-accent text-primary' : 'hover:bg-primary-light'}`}>Home</NavLink>
          <NavLink to="/logbook" className={({ isActive }) => `flex-1 text-center py-2 rounded ${isActive ? 'bg-accent text-primary' : 'hover:bg-primary-light'}`}>Logbook</NavLink>
          <NavLink to="/chat" className={({ isActive }) => `flex-1 text-center py-2 rounded ${isActive ? 'bg-accent text-primary' : 'hover:bg-primary-light'}`}>Chat</NavLink>
          <NavLink to="/settings" className={({ isActive }) => `flex-1 text-center py-2 rounded ${isActive ? 'bg-accent text-primary' : 'hover:bg-primary-light'}`}>Export</NavLink>
        </nav>
      </div>
    </BrowserRouter>
  );
}

export default App;