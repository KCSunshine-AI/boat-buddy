module.exports = {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}'
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#0f172a',
          light: '#1e293b',
          dark: '#0d1324'
        },
        accent: {
          DEFAULT: '#38bdf8',
          light: '#7dd3fc',
          dark: '#0284c7'
        }
      }
    },
  },
  plugins: [],
};